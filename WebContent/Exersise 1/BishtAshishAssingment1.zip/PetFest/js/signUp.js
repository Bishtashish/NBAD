// $(window).on('load', () => {
//     const elem = document. getElementById('signUpButton');
    
//     elem.setAttribute("disabled", "disabled");
//           elem.classList.add("disabled");
//     // elem.setAttribute("hover","disabled");
//     // elem.classList.remove("hover");
//   });

  window.onload = function() {
      document. getElementById('signUpButton').disabled = true;
    };